<?php
$pagina = 'contato';
include 'top.php';
?>

<!-- HEADER DA PÁGINA -->
<section class="page-header py-5">
  <div class="container">
    <div class="row align-items-center">
      <div class="col-lg-10">
        <h1 class="display-4 fw-bold mb-3">
         
          Fale Conosco
        </h1>
        <p class="lead text-muted">Entre em contato conosco para tirar suas dúvidas ou solicitar mais informações sobre nossos serviços.</p>
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php" class="text-decoration-none text-dark">Início</a></li>
            <li class="breadcrumb-item active" aria-current="page">Contato</li>
          </ol>
        </nav>
      </div>
      <div class="col-lg-2 text-lg-end">
        <img src="assets/img/Learning-rafiki.svg" alt="Ilustração de Contato" class="img-fluid d-none d-lg-block" style="max-width: 400px;">
      </div>
    </div>
  </div>
</section>

<!-- CONTATO SECTION -->
<section class="page-body py-5">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-lg-12">
        <div class="contact-container">
          <!-- Lado Esquerdo - Informações de Contato -->
          <div class="contact-info-side">
            <div class="contact-info-content">
              <h2 class="section-title text-white mb-4">
                <i class="fas fa-info-circle me-2"></i>
                Informações de Contato
              </h2>
              
              <div class="contact-details">
                <div class="contact-item">
                  <i class="fas fa-map-marker-alt"></i>
                  <div>
                    <h4>Endereço</h4>
                    <p>Av. Paulista, 1000 - São Paulo, SP</p>
                  </div>
                </div>

                <div class="contact-item">
                  <i class="fas fa-phone"></i>
                  <div>
                    <h4>Telefone</h4>
                    <p>(11) 9999-9999</p>
                  </div>
                </div>

                <div class="contact-item">
                  <i class="fas fa-envelope"></i>
                  <div>
                    <h4>E-mail</h4>
                    <p>contato@cientificoplus.com.br</p>
                  </div>
                </div>

                <div class="contact-item">
                  <i class="fas fa-clock"></i>
                  <div>
                    <h4>Horário de Atendimento</h4>
                    <p>Segunda a Sexta: 9h às 18h</p>
                  </div>
                </div>
              </div>

              <div class="social-links mt-4">
                <h4 class="text-white mb-3">Siga-nos nas Redes Sociais</h4>
                <div class="social-icons">
                  <a href="https://instagram.com/cientificoplus" target="_blank" class="social-icon">
                    <i class="fab fa-instagram"></i>
                  </a>
                  <a href="https://wa.me/5511999999999" target="_blank" class="social-icon">
                    <i class="fab fa-whatsapp"></i>
                  </a>
                  <a href="#" class="social-icon">
                    <i class="fab fa-facebook"></i>
                  </a>
                </div>
              </div>
            </div>
          </div>

          <!-- Lado Direito - Formulário de Contato -->
          <div class="contact-form-side">
            <h2 class="section-title mb-4">
              <i class="fas fa-envelope me-2"></i>
              Envie sua Mensagem
            </h2>
            <form class="contact-form" action="processar-contato.php" method="POST">
              <div class="form-group mb-3">
                <label for="nome" class="form-label">Nome Completo</label>
                <div class="input-group">
                  <span class="input-group-text">
                    <i class="fas fa-user"></i>
                  </span>
                  <input type="text" class="form-control" id="nome" name="nome" placeholder="Digite seu nome" required>
                </div>
              </div>

              <div class="form-group mb-3">
                <label for="email" class="form-label">E-mail</label>
                <div class="input-group">
                  <span class="input-group-text">
                    <i class="fas fa-envelope"></i>
                  </span>
                  <input type="email" class="form-control" id="email" name="email" placeholder="Digite seu e-mail" required>
                </div>
              </div>

              <div class="form-group mb-3">
                <label for="assunto" class="form-label">Assunto</label>
                <div class="input-group">
                  <span class="input-group-text">
                    <i class="fas fa-tag"></i>
                  </span>
                  <select class="form-select" id="assunto" name="assunto" required>
                    <option value="">Selecione um assunto</option>
                    <option value="duvida">Dúvida</option>
                    <option value="orcamento">Orçamento</option>
                    <option value="parceria">Parceria</option>
                    <option value="outro">Outro</option>
                  </select>
                </div>
              </div>

              <div class="form-group mb-3">
                <label for="mensagem" class="form-label">Mensagem</label>
                <div class="input-group">
                  <span class="input-group-text">
                    <i class="fas fa-comment"></i>
                  </span>
                  <textarea class="form-control" id="mensagem" name="mensagem" rows="5" placeholder="Digite sua mensagem" required></textarea>
                </div>
              </div>

              <button type="submit" class="btn btn-primary w-100">
                <i class="fas fa-paper-plane me-2"></i>
                Enviar Mensagem
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- CTA SECTION -->
<section class="benefits py-5 bg-light">
  <div class="container">
    <div class="row justify-content-center text-center mb-5">
      <div class="col-lg-8">
        <h2 class="section-title">
          Como Podemos Ajudar?
        </h2>
        <p class="lead text-muted">Estamos prontos para atender suas necessidades acadêmicas</p>
      </div>
    </div>

    <div class="row g-4">
      <div class="col-md-4">
        <div class="benefit-card">
          <div class="benefit-icon">
            <i class="fas fa-headset"></i>
          </div>
          <h4>Suporte Dedicado</h4>
          <p>Atendimento personalizado para resolver suas dúvidas</p>
        </div>
      </div>
      <div class="col-md-4">
        <div class="benefit-card">
          <div class="benefit-icon">
            <i class="fas fa-clock"></i>
          </div>
          <h4>Resposta Rápida</h4>
          <p>Retornamos sua mensagem em até 24 horas úteis</p>
        </div>
      </div>
      <div class="col-md-4">
        <div class="benefit-card">
          <div class="benefit-icon">
            <i class="fas fa-comments"></i>
          </div>
          <h4>Múltiplos Canais</h4>
          <p>Entre em contato por e-mail, WhatsApp ou redes sociais</p>
        </div>
      </div>
      <div class="col-md-12 text-center">
        <a href="trabalhos.php" class="btn btn-primary">
          <i class="fas fa-arrow-right me-2"></i>
          Ver Trabalhos Disponíveis
        </a>
      </div>
    </div>
  </div>
</section>

<?php include 'rodape.php'; ?> 