function lgpd(config) {
    // Configurações padrão
    const defaultConfig = {
        status: true,
        position: 'bottom', // opções: 'bottom', 'bottom-right', 'bottom-left'
        backgroundColor: '#333',
        textColor: '#f1f1f1',
        buttonBackgroundColor: '#4CAF50',
        buttonTextColor: '#fff',
        buttonRejectBackgroundColor: '#f44336',
        buttonRejectTextColor: '#fff',
        text: '<b>Nós usamos cookies!</b><br>Eles são usados para aprimorar a sua experiência. Ao fechar este banner ou continuar na página, você concorda com o uso de cookies.',
        buttonAcceptText: 'Aceitar',
        buttonReject: true,
        buttonRejectText: 'Recusar',
        linkPolicy: '#', // Link para a política de cookies
        saveConsentUrl: '', // URL para salvar o consentimento no banco de dados
        cookieDuration: 365, // duração em dias
        csrfToken: '' // Token CSRF para validação no servidor
    };

    // Mescla as configurações do usuário com as configurações padrão
    const settings = { ...defaultConfig, ...config };

    if (!settings.status || !settings.saveConsentUrl || !settings.csrfToken) return; // Se estiver desativado ou sem URL/token, não faz nada

    // Cria o CSS do banner
    const css = `
        #cookie-consent-banner {
            display: none;
            position: fixed;
            ${settings.position === 'top' ? 'top: 0; width: 100%;' : ''}
            ${settings.position === 'bottom' ? 'bottom: 0; width: 100%;' : ''}
            ${settings.position === 'bottom-right' ? 'bottom: 10px; right: 20px; max-width: 300px;  border-radius: 8px;' : ''}
            ${settings.position === 'bottom-left' ? 'bottom: 10px; left: 20px; max-width: 300px;  border-radius: 8px;' : ''}

            background-color: ${settings.backgroundColor};
            color: ${settings.textColor};
            padding: 15px;
           
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
            font-family: Arial, sans-serif;
            z-index: 1000;
            
            text-align: center;
        }
        #cookie-consent-banner p {
            margin: 0;
            font-size: 0.8em;
        }
        #cookie-consent-banner a {
            color: ${settings.textColor};
            text-decoration: underline;
        }
        .cookie-buttons {
            display: flex;
            gap: 10px;
            margin-top: 10px;
            justify-content: center;
        }
        .cookie-btn {
            padding: 4px 10px;
            border: none;
            cursor: pointer;
            border-radius: 4px;
            font-weight: bold;
            font-size: 0.8em;
        }
        .cookie-btn.accept {
            background-color: ${settings.buttonBackgroundColor};
            color: ${settings.buttonTextColor};
        }
        .cookie-btn.reject {
            background-color: ${settings.buttonRejectBackgroundColor};
            color: ${settings.buttonRejectTextColor};
        }
    `;

    // Insere o CSS no documento
    const style = document.createElement('style');
    style.innerHTML = css;
    document.head.appendChild(style);

    // Cria o HTML do banner de cookies
    const banner = document.createElement('div');
    banner.id = 'cookie-consent-banner';
    let  htmlbuttonReject = '';
    if(settings.buttonReject === true) {
           htmlbuttonReject =  `<button class="cookie-btn reject" onclick="handleConsent('rejected')">${settings.buttonRejectText}</button>`;
    }  

    banner.innerHTML = `
        <p>${settings.text}</p>
        <div class="cookie-buttons">
            <button class="cookie-btn accept" onclick="handleConsent('accepted')">${settings.buttonAcceptText}</button>
            ${htmlbuttonReject}
        </div>
    `;
    document.body.appendChild(banner);

    // Funções de Cookie
    function setCookie(name, value, days) {
        const d = new Date();
        d.setTime(d.getTime() + (days * 24 * 60 * 60 * 1000));
        const expires = "expires=" + d.toUTCString();
        document.cookie = `${name}=${value};${expires};path=/;SameSite=Strict`;
    }

    function getCookie(name) {
        const cookies = document.cookie.split("; ");
        for (let cookie of cookies) {
            let [cookieName, cookieValue] = cookie.split("=");
            if (cookieName === name) return cookieValue;
        }
        return null;
    }

    // Exibe o banner se o consentimento ainda não estiver salvo
    if (!getCookie("userUUID")) {
        banner.style.display = 'block';
    }

    // Função para gerenciar o consentimento
    window.handleConsent = function(consent) {
        // Validação do valor de consentimento
        if (consent !== 'accepted' && consent !== 'rejected') return;

        const userUUID = getCookie("userUUID") || generateUUID();
        setCookie("userUUID", userUUID, settings.cookieDuration);
        saveConsentToServer(consent, userUUID);
        banner.style.display = 'none';
    };

    // Função para gerar um UUID
    function generateUUID() {
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
            const r = Math.random() * 16 | 0, v = c === 'x' ? r : (r & 0x3 | 0x8);
            return v.toString(16);
        });
    }


    function saveConsentToServer(consent, userUUID) {
        fetch(settings.saveConsentUrl, {
            method: "POST",
            headers: { 
                "Content-Type": "application/x-www-form-urlencoded",
                "CSRF-Token": settings.csrfToken // Envia o token CSRF no cabeçalho
            },
            body: `consent=${consent}&userUUID=${userUUID}`
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                console.log("Consentimento salvo com sucesso.");
            } else {
                console.error("Erro ao salvar o consentimento.");
            }
        })
        .catch(error => console.error("Erro:", error));
    }

 
}
