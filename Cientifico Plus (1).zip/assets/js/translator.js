/**
 * Sistema de tradução simplificado para o site da Digitalit
 */
document.addEventListener('DOMContentLoaded', function() {
    // Adicionar eventos aos links de idiomas
    const langLinks = document.querySelectorAll('.language-link');
    langLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const lang = this.getAttribute('data-lang');
            
            // Lidar com o idioma português (padrão)
            if (lang === 'pt') {
                // Se já estiver traduzido, recarregar a página
                if (document.cookie.indexOf('googtrans') > -1) {
                    document.cookie = 'googtrans=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;';
                    document.cookie = 'googtrans=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/; domain=.' + document.domain;
                    window.location.reload();
                }
                return;
            }
            
            // Traduzir para o idioma selecionado
            if (typeof google === 'undefined' || typeof google.translate === 'undefined') {
                // Carregar o script do Google Translate se ainda não estiver carregado
                const script = document.createElement('script');
                script.src = '//translate.google.com/translate_a/element.js?cb=googleTranslateInit';
                document.body.appendChild(script);
                
                // Definir a função de callback
                window.googleTranslateInit = function() {
                    new google.translate.TranslateElement({
                        pageLanguage: 'pt',
                        includedLanguages: 'en,es',
                        autoDisplay: false,
                        layout: google.translate.TranslateElement.InlineLayout.SIMPLE
                    }, 'google_translate_element');
                    
                    // Definir o idioma selecionado
                    document.cookie = 'googtrans=/pt/' + lang;
                    window.location.reload();
                };
            } else {
                // O script já está carregado, apenas mudar o idioma
                document.cookie = 'googtrans=/pt/' + lang;
                window.location.reload();
            }
        });
    });
    
    // Marcar visualmente o idioma ativo
    const currentLang = document.cookie.match(/googtrans=\/pt\/([a-z]{2})/);
    if (currentLang && currentLang[1]) {
        const activeLang = currentLang[1];
        document.querySelector(`.language-link[data-lang="${activeLang}"]`)?.classList.add('active-lang');
    } else {
        document.querySelector('.language-link[data-lang="pt"]')?.classList.add('active-lang');
    }
}); 