// Animações da página institucional
document.addEventListener('DOMContentLoaded', function() {
    // Adiciona a animação de entrada para o conteúdo
    const contentElements = document.querySelectorAll('.animate-content');
    contentElements.forEach(element => {
        // Verifica se o elemento está visível na tela
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.1 });
        
        observer.observe(element);
    });
}); 