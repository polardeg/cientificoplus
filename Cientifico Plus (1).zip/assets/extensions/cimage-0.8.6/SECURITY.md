Security policy
======================

To report security vulnerabilities in the project, send en email to mikael.t.h.roos@gmail.com.

For other security related issues, please open an issue on the project.
