/**
 * Swiper 11.2.5
 * Most modern mobile touch slider and framework with hardware accelerated transitions
 * https://swiperjs.com
 *
 * Copyright 2014-2025 Vladimir Kharlampidi
 *
 * Released under the MIT License
 *
 * Released on: March 3, 2025
 */

export { S as Swiper, S as default } from './shared/swiper-core.mjs';
