<?php
$pagina = 'certificados';
include 'top.php';
?>

<!-- HEADER DA PÁGINA -->
<section class="page-header py-5">
  <div class="container">
    <div class="row align-items-center">
      <div class="col-lg-10">
        <h1 class="display-4 fw-bold mb-3"> 
          Certificados  
        </h1>
        <p class="lead text-muted">Emita ou valide seus certificados de forma rápida e segura</p>
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php" class="text-decoration-none text-dark">Início</a></li>
            <li class="breadcrumb-item active" aria-current="page">Certificados</li>
          </ol>
        </nav>
      </div>
      <div class="col-lg-2 text-lg-end">
        <img src="assets/img/Certification-amico.svg" alt="Ilustração de Certificados" class="img-fluid d-none d-lg-block" style="max-width: 400px;">
      </div>
    </div>
  </div>
</section>


<!-- CERTIFICADOS ACTIONS -->
<section class="certificate-actions py-5 bg-light">
  <div class="container"> 
    <div class="row g-4 justify-content-center">
      <!-- Emitir Certificado -->
      <div class="col-md-6">
        <div class="certificate-action-card">
          <div class="action-icon">
            <i class="fas fa-certificate"></i>
          </div>
          <h3>Emitir Certificado</h3>
          <p>Gere seu certificado digital após a publicação do trabalho. O documento será disponibilizado instantaneamente com QR Code para validação.</p>
          <ul class="action-features">
            <li><i class="fas fa-check"></i> Download imediato</li>
            <li><i class="fas fa-check"></i> QR Code de validação</li>
            <li><i class="fas fa-check"></i> Assinatura digital</li>
          </ul>
          <a href="emitir-certificado.php" class="btn btn-primary">
            <i class="fas fa-file-certificate me-2"></i>
            Emitir Certificado
          </a>
        </div>
      </div>

      <!-- Validar Certificado -->
      <div class="col-md-6">
        <div class="certificate-action-card">
          <div class="action-icon">
            <i class="fas fa-qrcode"></i>
          </div>
          <h3>Validar Certificado</h3>
          <p>Verifique a autenticidade de qualquer certificado emitido através do nosso sistema usando o QR Code ou número de validação.</p>
          <ul class="action-features">
            <li><i class="fas fa-check"></i> Validação online</li>
            <li><i class="fas fa-check"></i> Histórico completo</li>
            <li><i class="fas fa-check"></i> Relatório de autenticidade</li>
          </ul>
          <a href="validar-certificado.php" class="btn btn-primary">
            <i class="fas fa-qrcode me-2"></i>
            Validar Certificado
          </a>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- CERTIFICADOS SECTION -->
<section class="page-body py-5">
  <div class="container">
    <div class="row g-4">
      <!-- Certificado Digital -->
      <div class="col-md-6 col-lg-3">
        <div class="certificate-card">
          <div class="certificate-icon">
            <i class="fas fa-shield-alt"></i>
          </div>
          <h4>Certificado Digital</h4>
          <p>Certificados com QR Code para validação online e assinatura digital.</p>
        </div>
      </div>

      <!-- Validação Nacional -->
      <div class="col-md-6 col-lg-3">
        <div class="certificate-card">
          <div class="certificate-icon">
            <i class="fas fa-check-circle"></i>
          </div>
          <h4>Validação Nacional</h4>
          <p>Reconhecidos em todo o território nacional para residências, mestrado e doutorado.</p>
        </div>
      </div>

      <!-- Download Imediato -->
      <div class="col-md-6 col-lg-3">
        <div class="certificate-card">
          <div class="certificate-icon">
            <i class="fas fa-download"></i>
          </div>
          <h4>Download Imediato</h4>
          <p>Acesso instantâneo ao certificado após a publicação do trabalho.</p>
        </div>
      </div>

      <!-- Validade Perpétua -->
      <div class="col-md-6 col-lg-3">
        <div class="certificate-card">
          <div class="certificate-icon">
            <i class="fas fa-clock"></i>
          </div>
          <h4>Validade Perpétua</h4>
          <p>Certificados com validade perpétua e armazenamento seguro.</p>
        </div>
      </div>
    </div>
  </div>
</section>
<?php include 'rodape.php'; ?> 