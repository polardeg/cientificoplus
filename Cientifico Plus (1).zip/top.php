<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Científico Plus</title>
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/extensions/swiper/swiper-bundle.min.css">
</head>

<body>

    <!-- NAVBAR -->
    <nav class="navbar navbar-expand-lg navbar-light shadow-sm sticky-top">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <img src="assets/img/logo.jpg" alt="Científico Plus Logo" class="logo-img">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarContent">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarContent">
                <ul class="navbar-nav mx-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link <?php echo ($pagina == 'inicio') ? 'active' : ''; ?>" href="index.php"><i class="fas fa-home me-1"></i>Início</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo ($pagina == 'trabalhos') ? 'active' : ''; ?>" href="trabalhos.php">Trabalhos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo ($pagina == 'servicos') ? 'active' : ''; ?>" href="servicos.php">Serviços</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo ($pagina == 'como-funciona') ? 'active' : ''; ?>" href="index.php#como-funciona">Como Funciona</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo ($pagina == 'certificados') ? 'active' : ''; ?>" href="certificados.php"> Certificados</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo ($pagina == 'contato') ? 'active' : ''; ?>" href="contato.php"> Contato</a>
                    </li>
                </ul>
                <div class="nav-buttons">
                    <a href="https://instagram.com/cientificoplus" target="_blank" class="nav-social-link">
                        <i class="fab fa-instagram"></i>
                    </a>
                    <a href="https://wa.me/5511999999999" target="_blank" class="nav-social-link">
                        <i class="fab fa-whatsapp"></i>
                    </a>
                    <a href="login.php" class="btn btn-outline-primary">
                        <i class="fas fa-sign-in-alt me-1"></i>
                        <span>Login</span>
                    </a>
                    <a href="cadastro.php" class="btn btn-primary">
                        <i class="fas fa-user-plus me-1"></i>
                        <span>Cadastrar-se</span>
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <script src="assets/js/bootstrap.bundle.min.js"></script>
</body>

</html>