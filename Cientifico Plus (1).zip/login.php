<?php
$pagina = 'login';
include 'top.php';
?>

<!-- LOGIN SECTION -->
<section class="login-section py-5">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-lg-5">
        <div class="login-card">
          <div class="login-header text-center mb-4">
            <h2>Bem-vindo de volta!</h2>
            <p class="text-muted">Entre com suas credenciais para acessar sua conta</p>
          </div>

          <form class="login-form" action="processar-login.php" method="POST">
            <div class="form-group mb-3">
              <label for="email" class="form-label">E-mail</label>
              <div class="input-group">
                <span class="input-group-text">
                  <i class="fas fa-envelope"></i>
                </span>
                <input type="email" class="form-control" id="email" name="email" placeholder="Digite seu e-mail" required>
              </div>
            </div>

            <div class="form-group mb-3">
              <label for="senha" class="form-label">Senha</label>
              <div class="input-group">
                <span class="input-group-text">
                  <i class="fas fa-lock"></i>
                </span>
                <input type="password" class="form-control" id="senha" name="senha" placeholder="Digite sua senha" required>
                <button class="btn btn-outline-secondary" type="button" id="toggleSenha">
                  <i class="fas fa-eye"></i>
                </button>
              </div>
            </div>

            <div class="form-group mb-3 d-flex justify-content-between align-items-center">
              <div class="form-check">
                <input type="checkbox" class="form-check-input" id="lembrar" name="lembrar">
                <label class="form-check-label" for="lembrar">Lembrar-me</label>
              </div>
              <a href="recuperar-senha.php" class="text-primary text-decoration-none">Esqueceu a senha?</a>
            </div>

            <button type="submit" class="btn btn-primary w-100 mb-3">
              <i class="fas fa-sign-in-alt me-2"></i>
              Entrar
            </button>

            <div class="text-center">
              <p class="mb-0">Ainda não tem uma conta? <a href="cadastro.php" class="text-primary text-decoration-none">Cadastre-se</a></p>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</section>

<script>
document.getElementById('toggleSenha').addEventListener('click', function() {
  const senhaInput = document.getElementById('senha');
  const icon = this.querySelector('i');
  
  if (senhaInput.type === 'password') {
    senhaInput.type = 'text';
    icon.classList.remove('fa-eye');
    icon.classList.add('fa-eye-slash');
  } else {
    senhaInput.type = 'password';
    icon.classList.remove('fa-eye-slash');
    icon.classList.add('fa-eye');
  }
});
</script>

<?php include 'rodape.php'; ?> 