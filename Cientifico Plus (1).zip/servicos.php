<?php
$pagina = 'servicos';
include 'top.php';
?>

<!-- HEADER DA PÁGINA -->
<section class="page-header py-5">
  <div class="container">
    <div class="row align-items-center">
      <div class="col-lg-10">
        <h1 class="display-4 fw-bold mb-3"> 
          Serviços que Oferecemos
        </h1>
        <p class="lead text-muted">Soluções completas para impulsionar sua carreira acadêmica e potencializar seu currículo.</p>
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php" class="text-decoration-none text-dark">Início</a></li>
            <li class="breadcrumb-item active" aria-current="page">Serviços</li>
          </ol>
        </nav>
      </div>
      <div class="col-lg-2 text-lg-end">
        <img src="assets/img/Learning-cuate.svg" alt="Ilustração de Serviços" class="img-fluid d-none d-lg-block" style="max-width: 400px;">
      </div>
    </div>
  </div>
</section>

<!-- SERVIÇOS SECTION -->
<section class="page-body py-5">
  <div class="container">
    <div class="row g-4">
      <!-- Publicação de Trabalhos -->
      <div class="col-md-6 col-lg-4">
        <div class="service-card">
          <div class="service-icon">
            <i class="fas fa-file-alt"></i>
          </div>
          <h3>Publicação de Trabalhos</h3>
          <p>Publicação de resumos, artigos e capítulos de livro em revistas e congressos de renome.</p>
        </div>
      </div>

      <!-- Participação em Congressos -->
      <div class="col-md-6 col-lg-4">
        <div class="service-card">
          <div class="service-icon">
            <i class="fas fa-users"></i>
          </div>
          <h3>Participação em Congressos</h3>
          <p>Participação em congressos nacionais e internacionais com certificados válidos.</p>
        </div>
      </div>

      <!-- Currículo Lattes -->
      <div class="col-md-6 col-lg-4">
        <div class="service-card">
          <div class="service-icon">
            <i class="fas fa-user-graduate"></i>
          </div>
          <h3>Currículo Lattes</h3>
          <p>Elaboração e avaliação profissional do seu Currículo Lattes para destacar suas conquistas.</p>
        </div>
      </div>

      <!-- Certificados Digitais -->
      <div class="col-md-6 col-lg-4">
        <div class="service-card">
          <div class="service-icon">
            <i class="fas fa-certificate"></i>
          </div>
          <h3>Certificados Digitais</h3>
          <p>Emissão de certificados digitais com QR Code para validação online.</p>
        </div>
      </div>

      <!-- Mentoria Acadêmica -->
      <div class="col-md-6 col-lg-4">
        <div class="service-card">
          <div class="service-icon">
            <i class="fas fa-chalkboard-teacher"></i>
          </div>
          <h3>Mentoria Acadêmica</h3>
          <p>Orientação estratégica para planejar e alcançar seus objetivos acadêmicos.</p>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- CTA SECTION -->
<section class="benefits py-5 bg-light">
  <div class="container">
    <div class="row justify-content-center text-center mb-5">
      <div class="col-lg-8">
        <h2 class="section-title">
          Por que Escolher Nossos Serviços?
        </h2>
        <p class="lead text-muted">Descubra as vantagens de trabalhar com o Científico Plus</p>
      </div>
    </div>

    <div class="row g-4">
      <div class="col-md-4">
        <div class="benefit-card">
          <div class="benefit-icon">
            <i class="fas fa-clock"></i>
          </div>
          <h4>Agilidade</h4>
          <p>Processo rápido e eficiente para todas as publicações</p>
        </div>
      </div>
      <div class="col-md-4">
        <div class="benefit-card">
          <div class="benefit-icon">
            <i class="fas fa-certificate"></i>
          </div>
          <h4>Certificação</h4>
          <p>Certificados digitais com QR Code para validação</p>
        </div>
      </div>
      <div class="col-md-4">
        <div class="benefit-card">
          <div class="benefit-icon">
            <i class="fas fa-check-circle"></i>
          </div>
          <h4>Qualidade</h4>
          <p>Revisão e formatação profissional de todos os trabalhos</p>
        </div>
      </div>
      <div class="col-md-12 text-center">
        <a href="trabalhos.php" class="btn btn-primary">
          <i class="fas fa-arrow-right me-2"></i>
          Ver Trabalhos Disponíveis
        </a>
      </div>
    </div>
  </div>
</section>

<?php include 'rodape.php'; ?> 