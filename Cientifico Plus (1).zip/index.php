<?php
$pagina = 'inicio';
include 'top.php';
include 'corpo.php';
include 'rodape.php';
?>
