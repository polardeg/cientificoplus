<?php
$pagina = 'cadastro';
include 'top.php';
?>

<!-- HEADER DA PÁGINA -->
<section class="page-header py-5">
  <div class="container">
    <div class="row align-items-center">
      <div class="col-lg-10">
        <h1 class="display-4 fw-bold mb-3"> 
          Criar Conta
        </h1>
        <p class="lead text-muted">Junte-se ao Científico Plus e comece a publicar seus trabalhos acadêmicos hoje mesmo.</p>
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php" class="text-decoration-none text-dark">Início</a></li>
            <li class="breadcrumb-item active" aria-current="page">Cadastro</li>
          </ol>
        </nav>
      </div>
      <div class="col-lg-2 text-lg-end">
        <img src="assets/img/Add User-amico.svg" alt="Ilustração de Cadastro" class="img-fluid d-none d-lg-block" style="max-width: 400px;">
      </div>
    </div>
  </div>
</section>

<!-- CADASTRO SECTION -->
<section class="page-body py-5">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-lg-12">
        <div class="register-card">
          <form class="register-form" action="processar-cadastro.php" method="POST">
            <!-- Dados Pessoais -->
            <div class="form-section mb-4">
              <h3 class="section-title">
                <i class="fas fa-user me-2"></i>
                Dados Pessoais
              </h3>
              <div class="row g-3">
                <div class="col-md-12">
                  <div class="form-group">
                    <label for="nome" class="form-label">Nome Completo</label>
                    <div class="input-group">
                      <span class="input-group-text">
                        <i class="fas fa-user"></i>
                      </span>
                      <input type="text" class="form-control" id="nome" name="nome" placeholder="Digite seu nome completo" required>
                    </div>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="email" class="form-label">E-mail</label>
                    <div class="input-group">
                      <span class="input-group-text">
                        <i class="fas fa-envelope"></i>
                      </span>
                      <input type="email" class="form-control" id="email" name="email" placeholder="seu@email.com" required>
                    </div>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="whatsapp" class="form-label">WhatsApp</label>
                    <div class="input-group">
                      <span class="input-group-text">
                        <i class="fab fa-whatsapp"></i>
                      </span>
                      <input type="tel" class="form-control" id="whatsapp" name="whatsapp" placeholder="(00) 00000-0000" required>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- Dados Acadêmicos -->
            <div class="form-section mb-4">
              <h3 class="section-title">
                <i class="fas fa-graduation-cap me-2"></i>
                Dados Acadêmicos
              </h3>
              <div class="row g-3">
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="instituicao" class="form-label">Instituição de Ensino</label>
                    <div class="input-group">
                      <span class="input-group-text">
                        <i class="fas fa-university"></i>
                      </span>
                      <input type="text" class="form-control" id="instituicao" name="instituicao" placeholder="Nome da Instituição" required>
                    </div>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="sigla" class="form-label">Sigla</label>
                    <div class="input-group">
                      <span class="input-group-text">
                        <i class="fas fa-font"></i>
                      </span>
                      <input type="text" class="form-control" id="sigla" name="sigla" placeholder="Ex: USP" required>
                    </div>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="nivel" class="form-label">Nível de Ensino</label>
                    <div class="input-group">
                      <span class="input-group-text">
                        <i class="fas fa-layer-group"></i>
                      </span>
                      <select class="form-select" id="nivel" name="nivel" required>
                        <option value="">Selecione o nível</option>
                        <option value="graduando">Graduando</option>
                        <option value="graduado">Graduado</option>
                        <option value="mestrando">Mestrando</option>
                        <option value="mestre">Mestre</option>
                        <option value="doutorando">Doutorando</option>
                        <option value="doutor">Doutor</option>
                        <option value="pos-doc">Pós-Doutorando</option>
                        <option value="professor">Professor</option>
                      </select>
                    </div>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="profissao" class="form-label">Profissão</label>
                    <div class="input-group">
                      <span class="input-group-text">
                        <i class="fas fa-briefcase"></i>
                      </span>
                      <input type="text" class="form-control" id="profissao" name="profissao" placeholder="Sua profissão" required>
                    </div>
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                    <label for="orcid" class="form-label">ORCID (opcional)</label>
                    <div class="input-group">
                      <span class="input-group-text">
                        <i class="fas fa-id-card"></i>
                      </span>
                      <input type="text" class="form-control" id="orcid" name="orcid" placeholder="0000-0000-0000-0000">
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- Senha -->
            <div class="form-section mb-4">
              <h3 class="section-title">
                <i class="fas fa-lock me-2"></i>
                Senha
              </h3>
              <div class="row g-3">
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="senha" class="form-label">Senha</label>
                    <div class="input-group">
                      <span class="input-group-text">
                        <i class="fas fa-key"></i>
                      </span>
                      <input type="password" class="form-control" id="senha" name="senha" placeholder="Mínimo 8 caracteres" required>
                    </div>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="confirmar_senha" class="form-label">Confirmar Senha</label>
                    <div class="input-group">
                      <span class="input-group-text">
                        <i class="fas fa-key"></i>
                      </span>
                      <input type="password" class="form-control" id="confirmar_senha" name="confirmar_senha" placeholder="Confirme sua senha" required>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="form-actions">
              <button type="submit" class="btn btn-primary btn-lg w-100">
                <i class="fas fa-user-plus me-2"></i>
                Cadastrar-se
              </button>
            </div>

            <div class="text-center mt-4">
              <p class="mb-0">Já tem uma conta? <a href="login.php">Faça login</a></p>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- CTA SECTION -->
<section class="benefits py-5 bg-light">
  <div class="container">
    <div class="row justify-content-center text-center mb-5">
      <div class="col-lg-8">
        <h2 class="section-title">
          Benefícios de Criar sua Conta
        </h2>
        <p class="lead text-muted">Descubra as vantagens de fazer parte do Científico Plus</p>
      </div>
    </div>

    <div class="row g-4">
      <div class="col-md-4">
        <div class="benefit-card">
          <div class="benefit-icon">
            <i class="fas fa-file-alt"></i>
          </div>
          <h4>Publicação Simplificada</h4>
          <p>Processo rápido e fácil para publicar seus trabalhos acadêmicos</p>
        </div>
      </div>
      <div class="col-md-4">
        <div class="benefit-card">
          <div class="benefit-icon">
            <i class="fas fa-certificate"></i>
          </div>
          <h4>Certificados Digitais</h4>
          <p>Receba certificados válidos nacionalmente com QR Code</p>
        </div>
      </div>
      <div class="col-md-4">
        <div class="benefit-card">
          <div class="benefit-icon">
            <i class="fas fa-chart-line"></i>
          </div>
          <h4>Acompanhamento</h4>
          <p>Acompanhe o status de suas publicações em tempo real</p>
        </div>
      </div>
      <div class="col-md-12 text-center">
        <a href="trabalhos.php" class="btn btn-primary">
          <i class="fas fa-arrow-right me-2"></i>
          Ver Trabalhos Disponíveis
        </a>
      </div>
    </div>
  </div>
</section>

<?php include 'rodape.php'; ?> 