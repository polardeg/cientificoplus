<!-- HERO -->
<section id="inicio" class="hero">
  <div class="container position-relative">
    <div class="row align-items-center justify-content-center">
      <div class="col-lg-6 text-lg-start text-center mb-4 mb-lg-0">
        <h1>Potencialize seu<br>Currículo Acadêmico</h1>
        <p class="hero-text">Participe de congressos, publique trabalhos e receba certificados válidos para residências, mestrado e doutorado.</p>
        <div class="hero-buttons">
          <a href="trabalhos.php" class="btn btn-primary btn-lg me-3">
            <i class="fas fa-arrow-right me-2"></i>
            Ver Trabalhos
          </a>
          <a href="como-funciona.php" class="btn btn-outline-primary btn-lg">
            <i class="fas fa-info-circle me-2"></i>
            Saiba Mais
          </a>
        </div>
      </div>
      <div class="col-lg-5 text-center">
        <img src="assets/img/Learning-amico (1).svg" alt="Ilustração Científica" class="hero-illustration img-fluid highlight-illustration">
      </div>
    </div>
  </div>
</section>

<!-- TRABALHOS DISPONÍVEIS -->
<section class="available-works py-5">
  <div class="container">
    <div class="row justify-content-center text-center mb-5">
      <div class="col-lg-8">
        <h2 class="section-title">
          <i class="fas fa-file-alt me-2"></i>
          Trabalhos Disponíveis
        </h2>
        <p class="lead text-muted">Escolha o tipo de trabalho que melhor se adequa às suas necessidades acadêmicas</p>
      </div>
    </div>

    <!-- Swiper -->
    <div class="swiper workSwiper position-relative">
      <div class="swiper-wrapper">
        <!-- Resumo Simples -->
        <div class="swiper-slide">
          <div class="work-card h-100">
            <div class="work-icon">
              <i class="fas fa-file-alt"></i>
            </div>
            <h3>Resumo Simples</h3>
            <div class="work-price">R$ 25,00</div>
            <p>Resumo conciso e objetivo, ideal para apresentações em congressos e eventos acadêmicos.</p>
            <a href="trabalhos.php" class="btn btn-primary">
              <i class="fas fa-check me-2"></i>
              Selecionar
            </a>
          </div>
        </div>

        <!-- Resumo Expandido -->
        <div class="swiper-slide">
          <div class="work-card h-100">
            <div class="work-icon">
              <i class="fas fa-file-word"></i>
            </div>
            <h3>Resumo Expandido</h3>
            <div class="work-price">R$ 35,00</div>
            <p>Versão mais detalhada do resumo, com maior profundidade e desenvolvimento do conteúdo.</p>
            <a href="trabalhos.php" class="btn btn-primary">
              <i class="fas fa-check me-2"></i>
              Selecionar
            </a>
          </div>
        </div>

        <!-- Trabalho Completo -->
        <div class="swiper-slide">
          <div class="work-card h-100">
            <div class="work-icon">
              <i class="fas fa-book"></i>
            </div>
            <h3>Trabalho Completo</h3>
            <div class="work-price">R$ 70,00</div>
            <p>Documento completo com introdução, desenvolvimento, metodologia, resultados e conclusões.</p>
            <a href="trabalhos.php" class="btn btn-primary">
              <i class="fas fa-check me-2"></i>
              Selecionar
            </a>
          </div>
        </div>

        <!-- Capítulo de Livro -->
        <div class="swiper-slide">
          <div class="work-card h-100">
            <div class="work-icon">
              <i class="fas fa-book-open"></i>
            </div>
            <h3>Capítulo de Livro</h3>
            <div class="work-price">R$ 60,00</div>
            <p>Capítulo completo para publicação em livro acadêmico, com revisão e formatação adequada.</p>
            <a href="trabalhos.php" class="btn btn-primary">
              <i class="fas fa-check me-2"></i>
              Selecionar
            </a>
          </div>
        </div>

        <!-- Artigo Científico NÃO Indexado -->
        <div class="swiper-slide">
          <div class="work-card h-100">
            <div class="work-icon">
              <i class="fas fa-file-medical"></i>
            </div>
            <h3>Artigo Científico NÃO Indexado</h3>
            <div class="work-price">R$ 70,00</div>
            <p>Artigo científico completo com metodologia, resultados e discussão, pronto para publicação.</p>
            <a href="trabalhos.php" class="btn btn-primary">
              <i class="fas fa-check me-2"></i>
              Selecionar
            </a>
          </div>
        </div>

        <!-- Artigo Científico Indexado -->
        <div class="swiper-slide">
          <div class="work-card h-100 featured">
            <div class="work-icon">
              <i class="fas fa-file-medical-alt"></i>
            </div>
            <h3>Artigo Científico Indexado</h3>
            <div class="work-price">R$ 250,00</div>
            <p>Artigo científico completo com indexação em bases de dados reconhecidas internacionalmente.</p>
            <a href="trabalhos.php" class="btn btn-primary">
              <i class="fas fa-check me-2"></i>
              Selecionar
            </a>
          </div>
        </div>

        <!-- Currículo Lattes -->
        <div class="swiper-slide">
          <div class="work-card h-100">
            <div class="work-icon">
              <i class="fas fa-user-graduate"></i>
            </div>
            <h3>Currículo Lattes</h3>
            <div class="work-price">R$ 250,00</div>
            <p>Formatação e avaliação profissional do seu Currículo Lattes para destacar suas conquistas.</p>
            <a href="trabalhos.php" class="btn btn-primary">
              <i class="fas fa-check me-2"></i>
              Selecionar
            </a>
          </div>
        </div>
      </div>
      <div class="swiper-pagination"></div>
      <div class="swiper-button-next"></div>
      <div class="swiper-button-prev"></div>
    </div>
  </div>
</section>

<!-- COMO FUNCIONA -->
<section id="como-funciona" class="py-5">
  <div class="container">
    <h2 class="section-title">
      <i class="fas fa-lightbulb me-2"></i>
      Como Funciona
    </h2>
    <div class="process-container">
      <div class="process-timeline">
        <div class="process-step">
          <div class="step-content">
            <div class="step-icon">
              <i class="fas fa-file-alt"></i>
            </div>
            <div class="step-info">
              <h3>1. Escolha o Trabalho</h3>
              <p>Selecione entre resumo, artigo ou capítulo de livro para sua publicação</p>
              <ul class="step-features">
                <li><i class="fas fa-check"></i> Resumos para congressos</li>
                <li><i class="fas fa-check"></i> Artigos científicos</li>
                <li><i class="fas fa-check"></i> Capítulos de livros</li>
              </ul>
            </div>
          </div>
          <div class="step-arrow">
            <i class="fas fa-arrow-right"></i>
          </div>
        </div>

        <div class="process-step">
          <div class="step-content">
            <div class="step-icon">
              <i class="fas fa-credit-card"></i>
            </div>
            <div class="step-info">
              <h3>2. Realize o Pagamento</h3>
              <p>Pague de forma segura via PIX, cartão de crédito ou boleto</p>
              <ul class="step-features">
                <li><i class="fas fa-check"></i> Pagamento em até 12x</li>
                <li><i class="fas fa-check"></i> Desconto para grupos</li>
                <li><i class="fas fa-check"></i> Preços acessíveis</li>
              </ul>
            </div>
          </div>
          <div class="step-arrow">
            <i class="fas fa-arrow-right"></i>
          </div>
        </div>

        <div class="process-step">
          <div class="step-content">
            <div class="step-icon">
              <i class="fas fa-clock"></i>
            </div>
            <div class="step-info">
              <h3>3. Aguarde a Publicação</h3>
              <p>Seu trabalho será revisado e publicado em até 48 horas</p>
              <ul class="step-features">
                <li><i class="fas fa-check"></i> Revisão profissional</li>
                <li><i class="fas fa-check"></i> Feedback detalhado</li>
                <li><i class="fas fa-check"></i> Suporte contínuo</li>
              </ul>
            </div>
          </div>
          <div class="step-arrow">
            <i class="fas fa-arrow-right"></i>
          </div>
        </div>

        <div class="process-step">
          <div class="step-content">
            <div class="step-icon">
              <i class="fas fa-award"></i>
            </div>
            <div class="step-info">
              <h3>4. Baixe o Certificado</h3>
              <p>Receba seu certificado digital válido nacionalmente</p>
              <ul class="step-features">
                <li><i class="fas fa-check"></i> Certificado digital</li>
                <li><i class="fas fa-check"></i> Validação online</li>
                <li><i class="fas fa-check"></i> Reconhecimento nacional</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- CERTIFICADOS -->
<section id="certificados" class="py-5 bg-light">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-lg-12 text-center">
        <h2 class="section-title"> 
          Certificados 
        </h2>
        <p class="lead mb-5">Receba certificados válidos nacionalmente para enriquecer seu currículo acadêmico</p>
        
        <div class="row justify-content-center g-4">
          <div class="col-md-4">
            <div class="certificate-card">
              <div class="certificate-icon">
                <i class="fas fa-shield-alt"></i>
              </div>
              <h4>Certificado Digital</h4>
              <p>QR Code para validação online</p>
            </div>
          </div>
          
          <div class="col-md-4">
            <div class="certificate-card">
              <div class="certificate-icon">
                <i class="fas fa-check-circle"></i>
              </div>
              <h4>Validação Nacional</h4>
              <p>Reconhecido em todo o Brasil</p>
            </div>
          </div>
          
          <div class="col-md-4">
            <div class="certificate-card">
              <div class="certificate-icon">
                <i class="fas fa-download"></i>
              </div>
              <h4>Download Imediato</h4>
              <p>Acesso instantâneo</p>
            </div>
          </div>
        </div>

        <div class="mt-5">
          <a href="certificados.php" class="btn btn-primary btn-lg">
            <i class="fas fa-arrow-right me-2"></i>
            Saiba Mais Sobre Certificados
          </a>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- DESTAQUES -->
<section class="highlights py-5 bg-light">
  <div class="container">
    <div class="row justify-content-center align-items-center mb-5">
      <div class="col-lg-7">
        <h2 class="section-title text-start"> Destaques</h2>
        <p class="highlight-description">Nossa plataforma tem se destacado no cenário acadêmico, proporcionando oportunidades de publicação e certificação para estudantes e profissionais em todo o Brasil. Confira nossos números que comprovam nossa excelência e credibilidade.</p>
      </div>
      <div class="col-lg-4">
        <img src="assets/img/Learning-rafiki.svg" alt="Ilustração de Conquistas" class="img-fluid highlight-illustration">
      </div>
    </div>
    <div class="row g-4 justify-content-center">
      <div class="col-md-4">
        <div class="stats-card">
          <div class="stats-content">
            <span class="stats-number" data-value="10000">10.000+</span>
            <div class="stats-icon">
              <i class="fas fa-certificate"></i>
            </div>
          </div>
          <div class="stats-footer">
            <span class="stats-label">Certificados Emitidos</span>
            <div class="stats-progress">
              <div class="progress-bar" style="width: 90%"></div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="stats-card">
          <div class="stats-content">
            <span class="stats-number">27</span>
            <div class="stats-icon">
              <i class="fas fa-map-marker-alt"></i>
            </div>
          </div>
          <div class="stats-footer">
            <span class="stats-label">Estados Atendidos</span>
            <div class="stats-progress">
              <div class="progress-bar" style="width: 100%"></div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="stats-card">
          <div class="stats-content">
            <span class="stats-number">4.9</span>
            <div class="stats-icon">
              <i class="fas fa-star"></i>
            </div>
          </div>
          <div class="stats-footer">
            <span class="stats-label">Avaliação Média</span>
            <div class="stats-progress">
              <div class="progress-bar" style="width: 98%"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- DEPOIMENTOS -->
<section class="testimonials py-5">
  <div class="container">
    <h2 class="section-title">Depoimentos</h2>
    <div class="row g-4">
      <div class="col-md-4">
        <div class="testimonial-card">
          <div class="testimonial-header">
            <img src="https://ui-avatars.com/api/?name=Maria+Silva&background=e85c13&color=fff" alt="Avatar" class="testimonial-avatar">
            <div class="testimonial-info">
              <h4>Maria Silva</h4>
              <div class="testimonial-stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
              </div>
            </div>
          </div>
          <p class="testimonial-text">"Excelente plataforma! Consegui publicar meu artigo rapidamente e o certificado foi aceito no processo seletivo do mestrado."</p>
        </div>
      </div>
      <div class="col-md-4">
        <div class="testimonial-card">
          <div class="testimonial-header">
            <img src="https://ui-avatars.com/api/?name=João+Santos&background=e85c13&color=fff" alt="Avatar" class="testimonial-avatar">
            <div class="testimonial-info">
              <h4>João Santos</h4>
              <div class="testimonial-stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
              </div>
            </div>
          </div>
          <p class="testimonial-text">"Processo muito profissional e rápido. O suporte sempre respondeu prontamente minhas dúvidas."</p>
        </div>
      </div>
      <div class="col-md-4">
        <div class="testimonial-card">
          <div class="testimonial-header">
            <img src="https://ui-avatars.com/api/?name=Ana+Oliveira&background=e85c13&color=fff" alt="Avatar" class="testimonial-avatar">
            <div class="testimonial-info">
              <h4>Ana Oliveira</h4>
              <div class="testimonial-stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
              </div>
            </div>
          </div>
          <p class="testimonial-text">"Recomendo muito! Já publiquei 3 trabalhos e todos foram aceitos nos processos seletivos que participei."</p>
        </div>
      </div>
    </div>
  </div>
</section> 
</section> 