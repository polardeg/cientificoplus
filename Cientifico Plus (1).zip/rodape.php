<!-- FOOTER -->
<footer class="footer-section">
    <div class="footer-top py-5">
        <div class="container">
            <div class="row g-4">
                <div class="col-lg-4 col-md-6">
                    <div class="footer-info text-white">
                        <img src="assets/img/logo.jpg" alt="Científico Plus Logo" class="footer-logo mb-4">
                        <p>Potencialize seu currículo acadêmico com publicações e certificados válidos para residências, mestrado e doutorado.</p>
                        <div class="mt-4">
                            <a href="#" class="btn btn-outline-light btn-sm me-2">
                                <i class="fas fa-envelope me-2"></i>contato@cientificopplus.com.br
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2 col-md-6">
                    <h5 class="footer-title">Links Rápidos</h5>
                    <ul class="footer-links">
                        <li><a href="trabalhos.php">Trabalhos</a></li>
                        <li><a href="como-funciona.php">Como Funciona</a></li>
                        <li><a href="certificados.php">Certificados</a></li>
                        <li><a href="contato.php">Contato</a></li>
                    </ul>
                </div>
                <div class="col-lg-3 col-md-6">
                    <h5 class="footer-title">Horário de Atendimento</h5>
                    <ul class="footer-schedule">
                        <li>
                            <i class="fas fa-clock"></i>
                            <span>Segunda a Sexta: 9h às 18h</span>
                        </li>
                        <li>
                            <i class="fas fa-clock"></i>
                            <span>Sábado: 9h às 13h</span>
                        </li>
                    </ul>
                </div>
                <div class="col-lg-3 col-md-6 text-white">
                    <h5 class="footer-title">Redes Sociais</h5>
                    <p class="mb-3">Siga-nos nas redes sociais e fique por dentro das novidades!</p>
                    <div class="footer-social">
                        <a href="https://instagram.com/cientificoplus" target="_blank" class="social-icon instagram">
                            <i class="fab fa-instagram"></i>
                        </a>
                        <a href="https://wa.me/5511999999999" target="_blank" class="social-icon whatsapp">
                            <i class="fab fa-whatsapp"></i>
                        </a>
                        <a href="#" class="social-icon facebook">
                            <i class="fab fa-facebook"></i>
                        </a>
                        <a href="#" class="social-icon linkedin">
                            <i class="fab fa-linkedin"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="footer-bottom py-3 text-white">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6 text-center text-md-start">
                    <small>&copy; <?php echo date('Y'); ?> Científico Plus. Todos os direitos reservados.</small>
                </div>
                <div class="col-md-6 text-center text-md-end">
                    <div class="footer-payment">
                        <i class="fab fa-cc-visa"></i>
                        <i class="fab fa-cc-mastercard"></i>
                        <i class="fab fa-pix"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>

<!-- Swiper JS -->
<script src="assets/extensions/swiper/swiper-bundle.min.js"></script>
<!-- Main JS -->
<script src="assets/js/main.js"></script>
</body>
</html>