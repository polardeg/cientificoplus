<?php
$page = 'trabalhos';
include 'top.php';
?>

<!-- HEADER DA PÁGINA -->
<section class="page-header py-5">
  <div class="container">
    <div class="row align-items-center">
      <div class="col-lg-10">
        <h1 class="display-4 fw-bold mb-3">
          Trabalhos Disponíveis
        </h1>
        <p class="lead text-muted">Escolha o tipo de trabalho que melhor se adequa às suas necessidades acadêmicas e comece a publicar hoje mesmo.</p>
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php" class="text-decoration-none text-dark">Início</a></li>
            <li class="breadcrumb-item active" aria-current="page">Trabalhos Disponíveis</li>
          </ol>
        </nav>
      </div>
      <div class="col-lg-2 text-lg-end">
        <img src="assets/img/Work-amico.svg" alt="Ilustração de Trabalhos" class="img-fluid d-none d-lg-block" style="max-width: 400px;">
      </div>
    </div>
  </div>
</section>

<!-- LISTA DE TRABALHOS -->
<section class="page-body py-5">
  <div class="container">
    <div class="row justify-content-center g-4">
      <!-- Resumo Simples -->
      <div class="col-lg-6">
        <div class="work-item">
          <div class="work-header">
            <div class="work-icon">
              <i class="fas fa-file-alt"></i>
            </div>
            <div class="work-title">
              <h3>Resumo Simples</h3>
              <div class="work-price">R$ 25,00</div>
            </div>
          </div>
          <div class="work-content">
            <p>Resumo conciso e objetivo, ideal para apresentações em congressos e eventos acadêmicos.</p>
            <ul class="work-features">
              <li><i class="fas fa-check"></i> Formatação ABNT</li>
              <li><i class="fas fa-check"></i> Revisão de texto</li>
              <li><i class="fas fa-check"></i> Certificado digital</li>
            </ul>
            <a href="checkout.php?tipo=resumo-simples" class="btn btn-primary">
              <i class="fas fa-shopping-cart me-2"></i>
              Selecionar
            </a>
          </div>
        </div>
      </div>

      <!-- Resumo Expandido -->
      <div class="col-lg-6">
        <div class="work-item">
          <div class="work-header">
            <div class="work-icon">
              <i class="fas fa-file-word"></i>
            </div>
            <div class="work-title">
              <h3>Resumo Expandido</h3>
              <div class="work-price">R$ 35,00</div>
            </div>
          </div>
          <div class="work-content">
            <p>Versão mais detalhada do resumo, com maior profundidade e desenvolvimento do conteúdo.</p>
            <ul class="work-features">
              <li><i class="fas fa-check"></i> Formatação ABNT</li>
              <li><i class="fas fa-check"></i> Revisão completa</li>
              <li><i class="fas fa-check"></i> Certificado digital</li>
            </ul>
            <a href="checkout.php?tipo=resumo-expandido" class="btn btn-primary">
              <i class="fas fa-shopping-cart me-2"></i>
              Selecionar
            </a>
          </div>
        </div>
      </div>

      <!-- Trabalho Completo -->
      <div class="col-lg-6">
        <div class="work-item">
          <div class="work-header">
            <div class="work-icon">
              <i class="fas fa-book"></i>
            </div>
            <div class="work-title">
              <h3>Trabalho Completo</h3>
              <div class="work-price">R$ 70,00</div>
            </div>
          </div>
          <div class="work-content">
            <p>Documento completo com introdução, desenvolvimento, metodologia, resultados e conclusões.</p>
            <ul class="work-features">
              <li><i class="fas fa-check"></i> Formatação ABNT</li>
              <li><i class="fas fa-check"></i> Revisão completa</li>
              <li><i class="fas fa-check"></i> Certificado digital</li>
            </ul>
            <a href="checkout.php?tipo=trabalho-completo" class="btn btn-primary">
              <i class="fas fa-shopping-cart me-2"></i>
              Selecionar
            </a>
          </div>
        </div>
      </div>

      <!-- Capítulo de Livro -->
      <div class="col-lg-6">
        <div class="work-item">
          <div class="work-header">
            <div class="work-icon">
              <i class="fas fa-book-open"></i>
            </div>
            <div class="work-title">
              <h3>Capítulo de Livro</h3>
              <div class="work-price">R$ 60,00</div>
            </div>
          </div>
          <div class="work-content">
            <p>Capítulo completo para publicação em livro acadêmico, com revisão e formatação adequada.</p>
            <ul class="work-features">
              <li><i class="fas fa-check"></i> Formatação ABNT</li>
              <li><i class="fas fa-check"></i> Revisão completa</li>
              <li><i class="fas fa-check"></i> Certificado digital</li>
            </ul>
            <a href="checkout.php?tipo=capitulo-livro" class="btn btn-primary">
              <i class="fas fa-shopping-cart me-2"></i>
              Selecionar
            </a>
          </div>
        </div>
      </div>

      <!-- Artigo Científico NÃO Indexado -->
      <div class="col-lg-6">
        <div class="work-item">
          <div class="work-header">
            <div class="work-icon">
              <i class="fas fa-file-medical"></i>
            </div>
            <div class="work-title">
              <h3>Artigo Científico NÃO Indexado</h3>
              <div class="work-price">R$ 70,00</div>
            </div>
          </div>
          <div class="work-content">
            <p>Artigo científico completo com metodologia, resultados e discussão, pronto para publicação.</p>
            <ul class="work-features">
              <li><i class="fas fa-check"></i> Formatação ABNT</li>
              <li><i class="fas fa-check"></i> Revisão completa</li>
              <li><i class="fas fa-check"></i> Certificado digital</li>
            </ul>
            <a href="checkout.php?tipo=artigo-nao-indexado" class="btn btn-primary">
              <i class="fas fa-shopping-cart me-2"></i>
              Selecionar
            </a>
          </div>
        </div>
      </div>

      <!-- Artigo Científico Indexado -->
      <div class="col-lg-6">
        <div class="work-item featured">
          <div class="work-header">
            <div class="work-icon">
              <i class="fas fa-file-medical-alt"></i>
            </div>
            <div class="work-title">
              <h3>Artigo Científico Indexado</h3>
              <div class="work-price">R$ 250,00</div>
            </div>
          </div>
          <div class="work-content">
            <p>Artigo científico completo com indexação em bases de dados reconhecidas internacionalmente.</p>
            <ul class="work-features">
              <li><i class="fas fa-check"></i> Formatação ABNT</li>
              <li><i class="fas fa-check"></i> Revisão completa</li>
              <li><i class="fas fa-check"></i> Indexação internacional</li>
              <li><i class="fas fa-check"></i> Certificado digital</li>
            </ul>
            <a href="checkout.php?tipo=artigo-indexado" class="btn btn-primary">
              <i class="fas fa-shopping-cart me-2"></i>
              Selecionar
            </a>
          </div>
        </div>
      </div>

      <!-- Currículo Lattes -->
      <div class="col-lg-6">
        <div class="work-item">
          <div class="work-header">
            <div class="work-icon">
              <i class="fas fa-user-graduate"></i>
            </div>
            <div class="work-title">
              <h3>Currículo Lattes</h3>
              <div class="work-price">R$ 250,00</div>
            </div>
          </div>
          <div class="work-content">
            <p>Formatação e avaliação profissional do seu Currículo Lattes para destacar suas conquistas.</p>
            <ul class="work-features">
              <li><i class="fas fa-check"></i> Formatação profissional</li>
              <li><i class="fas fa-check"></i> Avaliação completa</li>
              <li><i class="fas fa-check"></i> Sugestões de melhorias</li>
              <li><i class="fas fa-check"></i> Certificado digital</li>
            </ul>
            <a href="checkout.php?tipo=curriculo-lattes" class="btn btn-primary">
              <i class="fas fa-shopping-cart me-2"></i>
              Selecionar
            </a>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- cta para criar conta -->
<section class="benefits py-5 bg-light">
  <div class="container">
    <div class="row justify-content-center text-center mb-5">
      <div class="col-lg-8">
        <h2 class="section-title">
          Benefícios de Publicar Conosco
        </h2>
        <p class="lead text-muted">Descubra por que milhares de acadêmicos escolhem o Científico Plus para suas publicações</p>
      </div>
    </div>

    <div class="row g-4">
      <div class="col-md-4">
        <div class="benefit-card">
          <div class="benefit-icon">
            <i class="fas fa-clock"></i>
          </div>
          <h4>Publicação Rápida</h4>
          <p>Seu trabalho publicado em até 48 horas após a aprovação</p>
        </div>
      </div>
      <div class="col-md-4">
        <div class="benefit-card">
          <div class="benefit-icon">
            <i class="fas fa-certificate"></i>
          </div>
          <h4>Certificado Digital</h4>
          <p>Certificado válido nacionalmente com QR Code para validação</p>
        </div>
      </div>
      <div class="col-md-4">
        <div class="benefit-card">
          <div class="benefit-icon">
            <i class="fas fa-check-circle"></i>
          </div>
          <h4>Revisão Profissional</h4>
          <p>Revisão completa por profissionais especializados</p>
        </div>
      </div>
      <div class="col-md-12 text-center">
        <a href="cadastro" class="btn btn-primary">
          <i class="fas fa-user-plus me-2"></i>
          Criar Conta
        </a>
      </div>
    </div>
  </div>
</section>

<?php include 'rodape.php'; ?>